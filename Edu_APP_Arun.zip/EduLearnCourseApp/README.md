# EduLearn Course Management SPA

This is a beginner-friendly Angular Single Page Application for course management. It uses `AppModule` as the root module, static in-memory data, property binding, event binding, and two-way binding.

## Steps to Create and Run the Project

```bash
cd C:\Users\arunv\captsone_WP
npx -y @angular/cli@latest new EduLearnCourseApp --skip-git --routing=false --style=css --standalone=false --package-manager=npm
cd EduLearnCourseApp
npm install
ng serve
```

Open `http://localhost:4200/` in your browser.

## Install Dependencies and Run the App

```bash
cd C:\Users\arunv\captsone_WP\EduLearnCourseApp
npm install
ng serve
```

## Binding Explanation

- Property binding is used in `src/app/app.component.html`:
  - `[courses]="courses"`
  - `[selectedCourseId]="selectedCourse.id"`
  - `[course]="selectedCourse"`

- Event binding is used in `src/app/course-list/course-list.component.html`:
  - `(click)="viewDetails(course)"`

- Two-way binding is used in `src/app/course-detail/course-detail.component.html`:
  - `[(ngModel)]="course.title"`

## How to Test That Binding Works

1. Run `ng serve`.
2. Open the application in the browser.
3. Click `View Details` for a course in the list.
4. Confirm that the selected course appears in the details panel.
5. Edit the title in the input field.
6. Confirm that the updated title appears immediately in both the details panel and the course list.

## Expected UI Behavior

- A list of available courses is shown on the left side on desktop.
- The selected course details appear on the right side.
- Each course card has a `View Details` button.
- Clicking the button updates the detail component.
- Editing the title updates the UI in real time.
- On smaller screens, the layout stacks vertically.

## Short Explanation of Main Files

- `src/app/app.module.ts`: Root module that imports `BrowserModule` and `FormsModule`, and declares the components.
- `src/app/app.component.ts`: Stores the course data and the selected course.
- `src/app/app.component.html`: Connects `CourseListComponent` and `CourseDetailComponent`.
- `src/app/course.ts`: Defines the `Course` interface.
- `src/app/course-list/course-list.component.ts`: Shows the course list and emits the selected course.
- `src/app/course-detail/course-detail.component.ts`: Displays and edits the selected course details.
- `src/main.ts`: Bootstraps the Angular application using `AppModule`.

## Folder Structure

```text
EduLearnCourseApp/
├── src/
│   ├── app/
│   │   ├── course-list/
│   │   │   ├── course-list.component.ts
│   │   │   ├── course-list.component.html
│   │   │   └── course-list.component.css
│   │   ├── course-detail/
│   │   │   ├── course-detail.component.ts
│   │   │   ├── course-detail.component.html
│   │   │   └── course-detail.component.css
│   │   ├── app.component.ts
│   │   ├── app.component.html
│   │   ├── app.component.css
│   │   ├── app.module.ts
│   │   └── course.ts
│   ├── main.ts
│   ├── index.html
│   └── styles.css
├── package.json
├── angular.json
├── tsconfig.json
└── README.md
```

## Useful Commands

```bash
cd C:\Users\arunv\captsone_WP\EduLearnCourseApp
npm install
ng serve
ng build
```
