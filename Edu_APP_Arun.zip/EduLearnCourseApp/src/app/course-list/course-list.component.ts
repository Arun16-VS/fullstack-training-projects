import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Course } from '../course';

@Component({
  selector: 'app-course-list',
  standalone: false,
  templateUrl: './course-list.component.html',
  styleUrl: './course-list.component.css'
})
export class CourseListComponent {
  @Input() courses: Course[] = [];
  @Input() selectedCourseId = 0;
  @Output() courseSelected = new EventEmitter<Course>();

  viewDetails(course: Course): void {
    this.courseSelected.emit(course);
  }
}
