import { Component } from '@angular/core';
import { Course } from './course';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'EduLearn Course Management SPA';

  courses: Course[] = [
    {
      id: 1,
      title: 'Angular Basics',
      instructor: 'varmaa',
      duration: '4 Weeks',
      description: 'Learn components, templates, modules, and data binding in Angular.'
    },
    {
      id: 2,
      title: 'TypeScript for Beginners',
      instructor: 'Leo Das',
      duration: '3 Weeks',
      description: 'Understand TypeScript syntax, interfaces, classes, and strong typing.'
    },
    {
      id: 3,
      title: 'Web UI Design Fundamentals',
      instructor: 'Sparrow Lee',
      duration: '5 Weeks',
      description: 'Explore layout, color, spacing, and responsive design for clean interfaces.'
    }
  ];

  selectedCourse: Course = this.courses[0];

  onCourseSelected(course: Course): void {
    this.selectedCourse = course;
  }
}
