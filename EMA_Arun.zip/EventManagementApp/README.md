# Event Management App

Event Management App is a beginner-friendly Angular application for displaying upcoming events using static in-memory data. It demonstrates core Angular concepts such as components, directives, pipes, interfaces, and animations in a simple assignment-ready structure.

## Installation Steps

```bash
npm install
ng serve
```

After running `ng serve`, open `http://localhost:4200/` in your browser.

## Brief Explanation

### EventListComponent

- Displays upcoming events using `*ngFor`
- Shows event name, date, ticket price, and category
- Uses a card-based layout for clean presentation

### PriceFormatPipe

- Formats numbers as Indian Rupee values
- Example outputs:
  - `500` becomes `₹500.00`
  - `1200` becomes `₹1,200.00`

### HighlightDirective

- Applies premium highlighting to events with a ticket price above `₹2000`
- Changes the event card background to light gold

### Animation Used

- A staggered Angular animation is used when the event cards first appear
- Cards fade in and slide upward for a smoother user experience

## Premium Event Identification

Premium events are identified when the ticket price is greater than `₹2000`. These events:

- Show a "Premium Event" badge
- Receive light gold highlighting through the custom directive

## Expected UI Behavior

- A simple hero section appears at the top of the app
- Event cards are displayed in a responsive grid
- All event details are clearly visible
- Ticket prices appear in rupee format
- Premium events stand out visually
- Cards animate into view on page load

## Folder Structure

```text
EventManagementApp/
├── src/
│   ├── app/
│   │   ├── components/
│   │   │   └── event-list/
│   │   │       ├── event-list.component.ts
│   │   │       ├── event-list.component.html
│   │   │       └── event-list.component.css
│   │   ├── directives/
│   │   │   └── highlight.directive.ts
│   │   ├── models/
│   │   │   └── event.model.ts
│   │   ├── pipes/
│   │   │   └── price-format.pipe.ts
│   │   ├── app.component.ts
│   │   ├── app.component.html
│   │   ├── app.component.css
│   │   ├── app.component.spec.ts
│   │   └── app.module.ts
│   ├── index.html
│   ├── main.ts
│   └── styles.css
├── angular.json
├── package.json
├── package-lock.json
├── tsconfig.json
└── README.md
```

## Terminal Commands

```bash
cd C:\Users\arunv\captsone_WP\EventManagementApp
npm install
ng serve
```

## How to Test the Pipe and Directive

### Test PriceFormatPipe

- Open the application in the browser
- Check the event price labels on each card
- Confirm values appear like `₹950.00`, `₹1,800.00`, and `₹4,500.00`

### Test HighlightDirective

- Look for event cards whose price is above `₹2000`
- Confirm those cards have a light gold background
- Confirm lower-priced events keep the normal white background

## Main File Overview

- `src/app/app.module.ts`: Registers the component, pipe, directive, and animation support
- `src/app/app.component.ts`: Root component for the application shell
- `src/app/components/event-list/event-list.component.ts`: Stores static event data and list logic
- `src/app/pipes/price-format.pipe.ts`: Formats ticket prices in rupees
- `src/app/directives/highlight.directive.ts`: Highlights premium event cards
- `src/app/models/event.model.ts`: Defines the event interface
