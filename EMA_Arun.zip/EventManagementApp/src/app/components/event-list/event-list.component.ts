import { Component } from '@angular/core';
import { animate, query, stagger, style, transition, trigger } from '@angular/animations';

import { Event } from '../../models/event.model';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrl: './event-list.component.css',
  standalone: false,
  animations: [
    trigger('cardStagger', [
      transition(':enter', [
        query(
          '.event-card',
          [
            style({ opacity: 0, transform: 'translateY(24px)' }),
            stagger(120, [
              animate(
                '500ms ease-out',
                style({ opacity: 1, transform: 'translateY(0)' })
              )
            ])
          ],
          { optional: true }
        )
      ])
    ])
  ]
})
export class EventListComponent {
  events: Event[] = [
    {
      name: 'Tech Innovators Conference',
      date: '2026-04-15',
      price: 1800,
      category: 'Technology'
    },
    {
      name: 'Creative Writing Workshop',
      date: '2026-04-22',
      price: 950,
      category: 'Workshop'
    },
    {
      name: 'Rock Music Concert',
      date: '2026-05-03',
      price: 3200,
      category: 'Entertainment'
    },
    {
      name: 'AI & Machine Learning Summit',
      date: '2026-05-18',
      price: 4500,
      category: 'Technology'
    }
  ];

  isPremium(price: number): boolean {
    return price > 2000;
  }
}
