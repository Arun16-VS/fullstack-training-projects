import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { EventListComponent } from './components/event-list/event-list.component';
import { HighlightDirective } from './directives/highlight.directive';
import { PriceFormatPipe } from './pipes/price-format.pipe';

@NgModule({
  declarations: [AppComponent, EventListComponent, PriceFormatPipe, HighlightDirective],
  imports: [BrowserModule, BrowserAnimationsModule],
  providers: [provideBrowserGlobalErrorListeners()],
  bootstrap: [AppComponent]
})
export class AppModule {}
