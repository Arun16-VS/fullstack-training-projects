import { Directive, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appHighlightPremium]',
  standalone: false
})
export class HighlightDirective {
  @HostBinding('style.backgroundColor') backgroundColor = '#ffffff';
  @HostBinding('style.borderColor') borderColor = '#d9e2ec';
  @HostBinding('style.boxShadow') boxShadow = '0 10px 30px rgba(15, 23, 42, 0.08)';

  @Input('appHighlightPremium') set price(value: number) {
    const isPremium = value > 2000;

    this.backgroundColor = isPremium ? '#fff5d6' : '#ffffff';
    this.borderColor = isPremium ? '#e0c46c' : '#d9e2ec';
    this.boxShadow = isPremium
      ? '0 14px 36px rgba(191, 151, 49, 0.18)'
      : '0 10px 30px rgba(15, 23, 42, 0.08)';
  }
}
