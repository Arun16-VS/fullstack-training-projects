const express = require('express');
const bookRouter = require('./routes/books');
const logger = require('./middleware/logger');

const app = express();
const PORT = 4000;

app.use(express.json());
app.use(logger);

app.get('/', (req, res) => {
  res.send('Welcome to Express Server');
});

app.get('/status', (req, res) => {
  res.json({
    server: 'running',
    uptime: 'OK'
  });
});

app.get('/products', (req, res) => {
  const { name } = req.query;

  if (!name) {
    return res.send('Please provide a product name');
  }

  return res.json({
    query: name
  });
});

app.use('/books', bookRouter);

app.use((req, res) => {
  res.status(404).send('Route not found');
});

app.use((err, req, res, next) => {
  console.error('Error:', err.message);
  res.status(500).json({
    error: 'Internal Server Error'
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
