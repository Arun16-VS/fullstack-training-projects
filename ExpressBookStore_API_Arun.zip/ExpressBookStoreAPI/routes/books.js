const express = require('express');

const router = express.Router();

let books = [
  { id: 1, title: '1984', author: 'Orwell' },
  { id: 2, title: 'The Alchemist', author: 'Coelho' }
];

router.get('/', (req, res) => {
  res.json(books);
});

router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  const book = books.find((item) => item.id === id);

  if (!book) {
    return res.status(404).json({
      message: 'Book not found'
    });
  }

  return res.json(book);
});

router.post('/', (req, res, next) => {
  try {
    const { title, author } = req.body;

    if (!title || !author) {
      return res.status(400).json({
        message: 'Title and author are required'
      });
    }

    const newBook = {
      id: books.length ? books[books.length - 1].id + 1 : 1,
      title,
      author
    };

    books.push(newBook);

    return res.status(201).json({
      message: 'Book added successfully',
      book: newBook
    });
  } catch (error) {
    return next(error);
  }
});

router.put('/:id', (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const { title, author } = req.body;
    const book = books.find((item) => item.id === id);

    if (!book) {
      return res.status(404).json({
        message: 'Book not found'
      });
    }

    if (!title || !author) {
      return res.status(400).json({
        message: 'Title and author are required'
      });
    }

    book.title = title;
    book.author = author;

    return res.json({
      message: 'Book updated successfully',
      book
    });
  } catch (error) {
    return next(error);
  }
});

router.delete('/:id', (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const bookIndex = books.findIndex((item) => item.id === id);

    if (bookIndex === -1) {
      return res.status(404).json({
        message: 'Book not found'
      });
    }

    const deletedBook = books[bookIndex];
    books.splice(bookIndex, 1);

    return res.json({
      message: 'Book deleted successfully',
      book: deletedBook
    });
  } catch (error) {
    return next(error);
  }
});

module.exports = router;
