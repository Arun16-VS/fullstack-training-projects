# Express BookStore API

A beginner-friendly Express.js project that demonstrates:

- Express server setup
- Basic routing
- Query parameters
- Custom middleware
- REST API CRUD operations
- Modular routing
- Error handling

## Project Structure

```text
ExpressBookStoreAPI/
├── middleware/
│   └── logger.js
├── routes/
│   └── books.js
├── server.js
├── package.json
├── package-lock.json
└── README.md
```

## Run the Project

```bash
npm install
node server.js
```

Server runs on:

```text
http://localhost:4000
```
