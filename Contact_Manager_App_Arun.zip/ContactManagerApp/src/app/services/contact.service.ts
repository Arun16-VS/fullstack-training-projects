import { Injectable } from '@angular/core';
import { Contact } from '../models/contact.model';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private contacts: Contact[] = [];

  getContacts(): Contact[] {
    return [...this.contacts];
  }

  addContact(contact: Contact): boolean {
    const duplicateContact = this.contacts.some(
      (existingContact) => existingContact.id === contact.id
    );

    if (duplicateContact) {
      return false;
    }

    this.contacts.push({ ...contact });
    return true;
  }

  updateContact(updatedContact: Contact): boolean {
    const contactIndex = this.contacts.findIndex(
      (contact) => contact.id === updatedContact.id
    );

    if (contactIndex === -1) {
      return false;
    }

    this.contacts[contactIndex] = { ...updatedContact };
    return true;
  }

  deleteContact(id: number): boolean {
    const initialLength = this.contacts.length;
    this.contacts = this.contacts.filter((contact) => contact.id !== id);
    return this.contacts.length !== initialLength;
  }
}
