import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Contact } from '../../models/contact.model';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'app-contact-manager',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './contact-manager.component.html',
  styleUrl: './contact-manager.component.css'
})
export class ContactManagerComponent {
  private readonly formBuilder = inject(FormBuilder);
  private readonly contactService = inject(ContactService);

  protected contacts: Contact[] = [];
  protected isEditMode = false;
  protected successMessage = '';
  protected errorMessage = '';

  protected readonly contactForm = this.formBuilder.group({
    id: ['', Validators.required],
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', Validators.required]
  });

  constructor() {
    this.loadContacts();
  }

  protected onSubmit(): void {
    this.clearMessages();

    if (this.contactForm.invalid) {
      this.contactForm.markAllAsTouched();
      this.errorMessage = 'Please fill in all fields correctly before submitting.';
      return;
    }

    const formValue = this.contactForm.getRawValue();
    const contact: Contact = {
      id: Number(formValue.id),
      name: formValue.name?.trim() ?? '',
      email: formValue.email?.trim() ?? '',
      phone: formValue.phone?.trim() ?? ''
    };

    if (Number.isNaN(contact.id)) {
      this.errorMessage = 'Contact ID must be a valid number.';
      return;
    }

    if (!this.isEditMode) {
      const wasAdded = this.contactService.addContact(contact);

      if (!wasAdded) {
        this.errorMessage = 'A contact with this ID already exists.';
        return;
      }

      this.successMessage = 'Contact added successfully.';
    } else {
      const wasUpdated = this.contactService.updateContact(contact);

      if (!wasUpdated) {
        this.errorMessage = 'Unable to update the selected contact.';
        return;
      }

      this.successMessage = 'Contact updated successfully.';
      this.isEditMode = false;
    }

    this.loadContacts();
    this.contactForm.get('id')?.enable();
    this.contactForm.reset();
  }

  protected editContact(contact: Contact): void {
    this.clearMessages();
    this.isEditMode = true;
    this.contactForm.get('id')?.disable();

    this.contactForm.patchValue({
      id: contact.id.toString(),
      name: contact.name,
      email: contact.email,
      phone: contact.phone
    });
  }

  protected deleteContact(id: number): void {
    this.clearMessages();

    const shouldDelete = window.confirm('Are you sure you want to delete this contact?');
    if (!shouldDelete) {
      return;
    }

    const wasDeleted = this.contactService.deleteContact(id);

    if (!wasDeleted) {
      this.errorMessage = 'Unable to delete the selected contact.';
      return;
    }

    if (this.isEditMode && Number(this.contactForm.get('id')?.value) === id) {
      this.cancelEdit();
    }

    this.loadContacts();
    this.successMessage = 'Contact deleted successfully.';
  }

  protected cancelEdit(): void {
    this.isEditMode = false;
    this.clearMessages();
    this.contactForm.get('id')?.enable();
    this.contactForm.reset();
  }

  protected getFieldError(fieldName: 'id' | 'name' | 'email' | 'phone'): string {
    const control = this.contactForm.get(fieldName);

    if (!control || !control.touched || !control.errors) {
      return '';
    }

    if (control.errors['required']) {
      return `${this.getFieldLabel(fieldName)} is required.`;
    }

    if (control.errors['email']) {
      return 'Please enter a valid email address.';
    }

    return '';
  }

  private loadContacts(): void {
    this.contacts = this.contactService.getContacts();
  }

  private clearMessages(): void {
    this.successMessage = '';
    this.errorMessage = '';
  }

  private getFieldLabel(fieldName: 'id' | 'name' | 'email' | 'phone'): string {
    const labels: Record<'id' | 'name' | 'email' | 'phone', string> = {
      id: 'Contact ID',
      name: 'Name',
      email: 'Email',
      phone: 'Phone'
    };

    return labels[fieldName];
  }
}
