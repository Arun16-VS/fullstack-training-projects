import { Component } from '@angular/core';
import { ContactManagerComponent } from './components/contact-manager/contact-manager.component';

@Component({
  selector: 'app-root',
  imports: [ContactManagerComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {}
