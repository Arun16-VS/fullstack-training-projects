const express = require('express');
const validateCourseId = require('../middleware/validateCourseId');

const router = express.Router();

router.get('/:id', validateCourseId, (req, res) => {
  res.json({
    id: req.params.id,
    name: 'React Mastery',
    duration: '6 weeks'
  });
});

module.exports = router;
