# SkillSphere LMS API

A simple Express.js backend project that demonstrates basic routing, dynamic routing, route-level middleware, input validation, modular routing, and JSON responses.

## Folder Structure

```text
SkillSphereLMSAPI/
+-- middleware/
�   +-- validateCourseId.js
+-- routes/
�   +-- courses.js
+-- node_modules/
+-- package-lock.json
+-- package.json
+-- README.md
+-- server.js
```

## Features

- Basic route using `GET /`
- Dynamic route using `GET /courses/:id`
- Route-level middleware for validating course ID
- JSON responses for API routes
- 404 handler for unknown routes
- Modular project structure

## Installation

```bash
npm install
```

## Run the Project

```bash
npm start
```

The server runs on:

```text
http://localhost:4000
```

## API Endpoints

### 1. Root Route

- Method: `GET`
- URL: `/`
- Response:

```text
Welcome to SkillSphere LMS API
```

### 2. Course Detail Route

- Method: `GET`
- URL: `/courses/:id`
- Example: `/courses/101`
- Success Response:

```json
{
  "id": "101",
  "name": "React Mastery",
  "duration": "6 weeks"
}
```

### 3. Invalid Course ID

- Method: `GET`
- URL: `/courses/abc`
- Error Response:

```json
{
  "error": "Invalid course ID"
}
```

### 4. Unknown Route

- Example: `/unknown`
- Response:

```json
{
  "error": "Route not found"
}
```

## File Explanation

### `server.js`

- Creates the Express application
- Sets the server port to `4000`
- Adds the root route
- Uses the course routes module
- Handles unknown routes with a 404 response
- Starts the server

### `routes/courses.js`

- Creates a router using Express
- Defines the dynamic route `GET /courses/:id`
- Applies `validateCourseId` middleware only to this route
- Returns course data in JSON format

### `middleware/validateCourseId.js`

- Checks whether `req.params.id` contains only numbers
- Sends an error response if the course ID is invalid
- Calls `next()` if the course ID is valid

## Testing

### Browser

1. Open `http://localhost:4000`
2. Open `http://localhost:4000/courses/101`
3. Open `http://localhost:4000/courses/abc`
4. Open `http://localhost:4000/unknown`

### Postman

1. Send a `GET` request to `http://localhost:4000`
2. Send a `GET` request to `http://localhost:4000/courses/101`
3. Send a `GET` request to `http://localhost:4000/courses/abc`
4. Send a `GET` request to `http://localhost:4000/unknown`
