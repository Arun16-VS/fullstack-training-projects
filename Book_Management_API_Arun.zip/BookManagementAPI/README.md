# Book Management REST API

A simple Node.js REST API built with Express.js to manage books stored in a JSON file.

## Project Structure

```text
book-api/
|-- data/
|   |-- books.json
|-- services/
|   |-- bookService.js
|-- server.js
|-- package.json
|-- package-lock.json
|-- README.md
```

## Setup Steps

1. Open terminal in the project folder.
2. Install dependencies.
3. Start the server.

## Install Commands

```bash
npm install
```

## Run Command

```bash
npm start
```

The server runs on:

```text
http://localhost:3000
```

## API Endpoints

### 1. Welcome Route

- Method: `GET`
- URL: `/`
- Response:

```json
{
  "message": "Welcome to Book Management API"
}
```

### 2. Get All Books

- Method: `GET`
- URL: `/books`

### 3. Get Book By ID

- Method: `GET`
- URL: `/books/:id`

### 4. Add New Book

- Method: `POST`
- URL: `/books`
- Request Body:

```json
{
  "title": "Atomic Habits",
  "author": "James Clear"
}
```

### 5. Update Book

- Method: `PUT`
- URL: `/books/:id`
- Request Body:

```json
{
  "title": "Deep Work",
  "author": "Cal Newport"
}
```

### 6. Delete Book

- Method: `DELETE`
- URL: `/books/:id`

## Error Responses

### Invalid ID

```json
{
  "message": "Invalid book ID"
}
```

### Book Not Found

```json
{
  "message": "Book not found"
}
```

### Missing Fields

```json
{
  "message": "Title and author are required"
}
```

## Postman Testing

### Add a Book

- Method: `POST`
- URL: `http://localhost:3000/books`
- Body: raw JSON

```json
{
  "title": "The Alchemist",
  "author": "Paulo Coelho"
}
```

### Get All Books

- Method: `GET`
- URL: `http://localhost:3000/books`

### Get One Book

- Method: `GET`
- URL: `http://localhost:3000/books/1`

### Update a Book

- Method: `PUT`
- URL: `http://localhost:3000/books/1`
- Body: raw JSON

```json
{
  "title": "The Alchemist Updated",
  "author": "Paulo Coelho"
}
```

### Delete a Book

- Method: `DELETE`
- URL: `http://localhost:3000/books/1`

## Notes

- Uses `async/await` for file operations.
- Uses Node.js `fs` module with JSON file storage.
- Uses `EventEmitter` to log book add, update, and delete actions.
- Uses CommonJS syntax.
