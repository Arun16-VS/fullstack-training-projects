const fs = require('fs').promises;
const path = require('path');
const EventEmitter = require('events');

const booksFilePath = path.join(__dirname, '..', 'data', 'books.json');
const bookEvents = new EventEmitter();

bookEvents.on('bookAdded', () => {
  console.log('Book Added');
});

bookEvents.on('bookUpdated', () => {
  console.log('Book Updated');
});

bookEvents.on('bookDeleted', () => {
  console.log('Book Deleted');
});

const readBooks = async () => {
  const data = await fs.readFile(booksFilePath, 'utf-8');
  return JSON.parse(data);
};

const writeBooks = async (books) => {
  await fs.writeFile(booksFilePath, JSON.stringify(books, null, 2));
};

const getAllBooks = async () => {
  return readBooks();
};

const getBookById = async (id) => {
  const books = await readBooks();
  return books.find((book) => book.id === id);
};

const addBook = async ({ title, author }) => {
  const books = await readBooks();

  const newBook = {
    id: books.length ? books[books.length - 1].id + 1 : 1,
    title,
    author,
  };

  books.push(newBook);
  await writeBooks(books);
  bookEvents.emit('bookAdded', newBook);

  return newBook;
};

const updateBook = async (id, updatedData) => {
  const books = await readBooks();
  const bookIndex = books.findIndex((book) => book.id === id);

  if (bookIndex === -1) {
    return null;
  }

  books[bookIndex] = {
    ...books[bookIndex],
    ...updatedData,
  };

  await writeBooks(books);
  bookEvents.emit('bookUpdated', books[bookIndex]);

  return books[bookIndex];
};

const deleteBook = async (id) => {
  const books = await readBooks();
  const bookIndex = books.findIndex((book) => book.id === id);

  if (bookIndex === -1) {
    return null;
  }

  const deletedBook = books[bookIndex];
  books.splice(bookIndex, 1);

  await writeBooks(books);
  bookEvents.emit('bookDeleted', deletedBook);

  return deletedBook;
};

module.exports = {
  getAllBooks,
  getBookById,
  addBook,
  updateBook,
  deleteBook,
};
