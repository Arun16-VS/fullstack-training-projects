import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Book } from '../../models/book.model';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-books',
  standalone: false,
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit, OnDestroy {
  books: Book[] = [];
  selectedBook: Book | null = null;
  booksForAsyncPipe$!: Observable<Book[]>;
  private booksSubscription?: Subscription;

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    const booksUrl = 'assets/books.json';

    this.booksForAsyncPipe$ = this.dataService.getData<Book[]>(booksUrl);

    this.booksSubscription = this.dataService.getData<Book[]>(booksUrl).subscribe({
      next: (response) => {
        this.books = response;
        this.selectedBook = response[0] ?? null;
      },
      error: (error) => {
        console.error('Error loading books:', error);
      }
    });
  }

  selectBook(book: Book): void {
    this.selectedBook = book;
  }

  ngOnDestroy(): void {
    this.booksSubscription?.unsubscribe();
  }
}
