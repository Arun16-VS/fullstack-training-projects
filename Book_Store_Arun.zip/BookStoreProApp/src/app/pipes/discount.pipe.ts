import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'discount',
  standalone: false
})
export class DiscountPipe implements PipeTransform {
  transform(price: number, discountPercent: number = 10): number {
    if (price == null || discountPercent < 0) {
      return price;
    }

    return price - (price * discountPercent) / 100;
  }
}
