export interface Book {
  id: number;
  title: string;
  author: string;
  price: number;
  publicationDate: string;
  description: string;
}
