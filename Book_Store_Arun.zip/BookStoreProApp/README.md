# BookStore Pro

BookStore Pro is a beginner-friendly Angular application for displaying and managing books using mock JSON data. It demonstrates `HttpClient`, Observables, an HTTP interceptor, parent-child communication with `@Input`, built-in pipes, and a custom `DiscountPipe`.

## Installation

```bash
npm install
ng serve
```

Open `http://localhost:4200/` in the browser after the development server starts.

## Step-by-Step Terminal Commands

```bash
cd C:\Users\arunv\captsone_WP\BookStoreProApp
npm install
ng serve
```

## Project Structure

```text
BookStoreProApp/
├── angular.json
├── package.json
├── README.md
├── tsconfig.app.json
├── tsconfig.json
├── tsconfig.spec.json
├── public/
│   └── favicon.ico
└── src/
    ├── assets/
    │   └── books.json
    ├── index.html
    ├── main.ts
    ├── styles.css
    └── app/
        ├── app.component.css
        ├── app.component.html
        ├── app.component.ts
        ├── app.module.ts
        ├── app.spec.ts
        ├── components/
        │   ├── book-card/
        │   │   ├── book-card.component.css
        │   │   ├── book-card.component.html
        │   │   └── book-card.component.ts
        │   └── books/
        │       ├── books.component.css
        │       ├── books.component.html
        │       └── books.component.ts
        ├── interceptors/
        │   └── auth.interceptor.ts
        ├── models/
        │   └── book.model.ts
        ├── pipes/
        │   └── discount.pipe.ts
        └── services/
            └── data.service.ts
```

## Main Concepts Used

### DataService

`DataService` is the central place for HTTP `GET` requests. It uses Angular `HttpClient` and returns Observables so components can subscribe to data streams.

### AuthInterceptor

`AuthInterceptor` adds a dummy `Authorization` header to every outgoing request. This shows how interceptors can modify requests globally before they are sent.

### Manual Subscribe and Unsubscribe

`BooksComponent` manually subscribes to one Observable and stores the returned `Subscription`. In `ngOnDestroy`, it calls `unsubscribe()` to avoid memory leaks.

### Async Pipe Usage

The same component also exposes `booksForAsyncPipe$` and uses the `async` pipe in the template. Angular handles the subscription and cleanup automatically in that case.

### Parent-Child Communication

`BooksComponent` acts as the parent and passes the selected book to `BookCardComponent` using `@Input()`. The child component simply receives the data and displays it.

## Pipes Used

Built-in pipes used in the project:

- `UpperCasePipe`: shows the book title in uppercase.
- `CurrencyPipe`: formats the price in INR.
- `DatePipe`: formats the publication date in a readable way.
- `SlicePipe`: limits the description preview to the first 50 characters.

Custom pipe used in the project:

- `DiscountPipe`: applies a discount percentage to the original price and returns the discounted value.

## How DiscountPipe Works

The pipe receives the original book price and an optional discount percentage. It calculates the reduced price using:

`discountedPrice = originalPrice - (originalPrice * discount / 100)`

For example, if the price is `799` and the discount is `10`, the pipe returns the value after reducing 10 percent.

## How to Test Manual Subscribe and Async Pipe Behavior

1. Run `ng serve`.
2. Open the app in the browser.
3. In the "Manual Subscribe Example" section, books appear because the component manually subscribes in `ngOnInit`.
4. Click any "View Details" button to pass the selected book from parent to child.
5. In the "Async Pipe Example" section, the second list appears using `booksForAsyncPipe$ | async`.
6. Navigate away or stop the app to understand that `ngOnDestroy` handles cleanup for the manual subscription, while the async pipe cleans itself automatically.

## Expected UI Behavior

- A page header explains the assignment demo.
- The manual subscription section shows book cards with title, author, price, publication date, description preview, and discounted price.
- Clicking a card button updates the selected book details in the child component.
- The async pipe section shows the same books in a lighter summary list.
- A loading or empty state message appears if there are no books to show.

## Short Explanation of Each Main File

- `app.module.ts`: registers components, `HttpClientModule`, the interceptor, and the custom pipe.
- `app.component.*`: provides the page shell and loads the books feature.
- `books.component.*`: fetches data, demonstrates manual subscribe and async pipe usage, and handles selected book state.
- `book-card.component.*`: child component that receives one book using `@Input()`.
- `data.service.ts`: central service for `HttpClient` GET calls returning Observables.
- `auth.interceptor.ts`: adds a dummy authorization header to every HTTP request.
- `discount.pipe.ts`: calculates discounted book prices.
- `book.model.ts`: defines the `Book` interface.
- `books.json`: stores mock API data locally.

## One-Page Summary for Submission

BookStore Pro uses Angular Observables to load data from a local JSON file through `HttpClient`. The `DataService` returns an Observable of books, which keeps the data flow reactive and easy to reuse. In `BooksComponent`, one Observable is consumed with a manual `subscribe()` method to demonstrate how developers can store the returned `Subscription` and clean it up inside `ngOnDestroy`. This is important because manual subscriptions should be unsubscribed when the component is destroyed to prevent memory leaks. The same component also demonstrates Angular's `async` pipe by binding another Observable directly in the template. With the `async` pipe, Angular automatically subscribes and unsubscribes, making the code shorter and safer for simple UI rendering.

The application uses four built-in pipes and one custom pipe to format data clearly for the user. `UpperCasePipe` makes the book title stand out, `CurrencyPipe` displays price values in INR, `DatePipe` converts the publication date into a readable format, and `SlicePipe` limits the description preview to the first 50 characters so the UI stays neat. A custom `DiscountPipe` calculates a discounted version of the original price and displays the offer price next to the main price. Parent-child communication is shown by sending the selected book from `BooksComponent` to `BookCardComponent` using `@Input()`. Together, these features make the project simple, practical, and easy to explain in a viva.
